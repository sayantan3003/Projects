package com.example.learn_springboot_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringbootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
