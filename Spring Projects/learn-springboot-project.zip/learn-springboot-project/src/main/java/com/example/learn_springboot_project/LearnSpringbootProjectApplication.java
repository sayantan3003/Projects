package com.example.learn_springboot_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnSpringbootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnSpringbootProjectApplication.class, args);
	}

}
