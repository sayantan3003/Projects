export default "sayantan";
export let apikey = "[p&oikjn*bvft@yu8765ewzxc";
export let familyname = "Das";
