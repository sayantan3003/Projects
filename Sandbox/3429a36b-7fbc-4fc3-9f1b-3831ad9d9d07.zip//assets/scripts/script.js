// import { apikey as api } from "./util";
// import str from "./util";
import * as util from "./util";

// console.log(api);
// console.log(str);

console.log(util.apikey);
console.log(util.default);
console.log(util.familyname);
